﻿Public Class Form1

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim doc As XDocument = XDocument.Load("bailes.xml")
        Dim baile15Plazas = _
                From baile In doc...<baile>
                Where (baile.<plazas>.Value > 15)
                Select baile
        Dim docAux As XDocument = _
                <?xml version="1.0" encoding="UTF-8"?>
                <bailes>
                    <%= baile15Plazas %>
                </bailes>

        docAux.Save("bailes2.xml")
        MessageBox.Show("Archivo creado", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Function docAux() As Object
        Throw New NotImplementedException
    End Function

End Class
