﻿Imports System.IO
Public Class Form1
    Dim fichero As StreamWriter
    Dim lector As StreamReader
    Dim linea As String
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        fichero = New StreamWriter("NOTAS.txt")

            fichero.WriteLine("La primera linea")
            fichero.WriteLine("de un microcuento")
            fichero.WriteLine("que no acaba aquí")
            fichero.Write("porque estamos probando")
            fichero.WriteLine("FIN")

            fichero.Close()
            MessageBox.Show("Fichero creado")


       


    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        lector = New StreamReader("NOTAS.txt")


        linea = lector.ReadLine()
        MessageBox.Show("Contenido de la primera linea: " & linea)

        linea = lector.ReadLine()
        MessageBox.Show("Contenido de la 2ª linea: " & linea)

        Dim texto As String
        texto = lector.ReadToEnd()
        MessageBox.Show("Resto del archivo: " & texto)
        lector.Close()

    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        fichero = New StreamWriter("NOTAS.txt", True) 'añade texto al final del archivo creado
        fichero.WriteLine("Esto es otra nueva linea")

       

        fichero.Close()

    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles btnExiste.Click
        Dim fs As StreamReader
        Dim fich As String = InputBox("Introduce nombre del archivo: ", "Fichero")
        Try

            If Not (File.Exists(fich)) Then
                MessageBox.Show("El fichero NO existe")

            Else
                fs = New StreamReader(fich)
                MessageBox.Show("El fichero existe")
                For i = 0 To 1
                    MessageBox.Show(fs.ReadLine)
                Next
                MessageBox.Show(fs.ReadToEnd)
                fs.Close()
            End If
        Catch ex As FileNotFoundException
            MessageBox.Show("Fichero no encontrado")
        End Try

    End Sub
End Class
