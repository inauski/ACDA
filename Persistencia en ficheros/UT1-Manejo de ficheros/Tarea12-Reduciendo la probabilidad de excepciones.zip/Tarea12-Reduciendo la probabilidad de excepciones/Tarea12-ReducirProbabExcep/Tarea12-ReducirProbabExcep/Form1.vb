﻿Imports System.IO
Public Class Form1

    Private Sub btnAbrir_Click(sender As System.Object, e As System.EventArgs) Handles btnAbrir.Click

        Dim openFileDialog As New OpenFileDialog()

        'openFileDialog.InitialDirectory = "c:\"
        If openFileDialog.ShowDialog() = DialogResult.OK Then
            Dim sr As New StreamReader(openFileDialog.FileName)
            TextBox1.Text = sr.ReadToEnd
            sr.Close()
        End If
    End Sub

    Private Sub btnGuardar_Click(sender As System.Object, e As System.EventArgs) Handles btnGuardar.Click

        Dim saveFileDialog As New SaveFileDialog()

        'El filtro consiste en una descripción del filtro seguida de una barra vertical (|) y el patrón de filtro. 
        saveFileDialog.Filter = "Archivos txt (*.txt)|*.txt|Todos los archivos(*.*)|*.*"  'Por un lado, seleccionamos TODOS los archivos txt. Por otro, Todos los tipos de archivos (*. *) | *. *
        saveFileDialog.FilterIndex = 2 ' Especifica qué filtro aparece primero en la lista desplegable Guardar como (TIPO),es decir, nos dice el TIPO que aparece primero en la lista cuando vayamos a guardar. Empieza en 1.
        saveFileDialog.RestoreDirectory = True 'Indica si el cuadro de diálogo restaura el directorio al directorio seleccionado previamente antes de cerrarse.


        If saveFileDialog.ShowDialog() = DialogResult.OK Then

            Dim sw As StreamWriter = New StreamWriter(saveFileDialog.OpenFile())
            If Not (sw Is Nothing) Then 'Podemos escribir If Not (sw Is Nothing), que es lo mismo. Is Nothing, devuelve un valor de tipo Boolean que indica si una expresión no tiene ningún objeto asignado.
                sw.Write(TextBox1.Text)
                sw.Close()
            End If
        End If
    End Sub
End Class

