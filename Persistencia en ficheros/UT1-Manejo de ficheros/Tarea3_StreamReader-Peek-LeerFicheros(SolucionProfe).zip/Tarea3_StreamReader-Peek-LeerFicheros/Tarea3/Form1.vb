﻿Imports System.IO

Public Class Form1

    Private Sub btLeer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btLeer.Click
        Try
            Dim fichero As String
            fichero = "d:\" & TextBox1.Text & ".txt"
            If Not (File.Exists(fichero)) Then
                File.Delete(fichero)
                MessageBox.Show("Fichero inexistente")
            Else
                Dim sr As StreamReader
                sr = New StreamReader(fichero)
                While (sr.Peek() > -1)
                    MessageBox.Show(sr.ReadLine())
                End While
                sr.Close()
            End If
        Catch ex As Exception
            MessageBox.Show("ERROR")
        End Try

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            Dim linea As String = "A"
            Dim fichero As String
            fichero = "d:\" & TextBox1.Text & ".txt"
            If Not (File.Exists(fichero)) Then
                File.Delete(fichero)
                MessageBox.Show("Fichero inexistente")
            Else
                Dim sr As StreamReader
                sr = New StreamReader(fichero)
                While linea <> ""
                    linea = sr.ReadLine
                    If linea = "" Then
                        Exit Sub
                    Else
                        MessageBox.Show(linea)
                    End If
                End While
            End If
        Catch ex As Exception
            MessageBox.Show("ERROR")
        End Try

    End Sub
End Class
