﻿Imports System
Imports System.IO
Public Class Form1

    Private Sub btnPath_Click(sender As System.Object, e As System.EventArgs) Handles btnPath.Click
        Dim op As String
        op = InputBox("Introduzca una ruta completa: ")
        MessageBox.Show("Ruta completa excepto nombre del fichero: " + Path.GetDirectoryName(op))
        MessageBox.Show("Nombre completo del fichero incluyendo su extensión " + Path.GetFileName(op))
        MessageBox.Show("La extension es: " + Path.GetExtension(op))
        MessageBox.Show("Nombre del archivo SIN la EXTENSIÓN: " + Path.GetFileNameWithoutExtension(op))
        MessageBox.Show("La unidad: " + Path.GetPathRoot(op))



    End Sub
End Class
