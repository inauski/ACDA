﻿Imports System.IO
Public Class Form1
    Dim fichero As StreamWriter
    Private Sub btnAñadir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAñadir.Click
        Dim nombre, dni, ruta As String

        nombre = txtNombre.Text
        dni = CStr(txtDNI.Text)
        ruta = "d:\Socios.txt"

        fichero = New StreamWriter(ruta, True) ' Si esta a false, sobreescribe todo lo que habia en Socios.txt

        fichero.WriteLine("--NUEVO SOCIO--")
        fichero.WriteLine("NOMBRE: " & nombre)
        fichero.WriteLine("DNI: " & dni)

        fichero.Close()

        MessageBox.Show("Nuevo socio añadido")
    End Sub

    Private Sub btnMostrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMostrar.Click
        Dim lector As StreamReader
        lector = New StreamReader("d:\Socios.txt")

        Dim texto As String
        texto = lector.ReadToEnd()
        MessageBox.Show(texto)

        lector.Close()
    End Sub
End Class
