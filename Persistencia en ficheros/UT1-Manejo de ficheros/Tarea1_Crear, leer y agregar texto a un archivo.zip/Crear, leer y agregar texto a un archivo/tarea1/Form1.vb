﻿Imports System.IO
Public Class Form1
    Dim fichero As StreamWriter
    Dim lector As StreamReader
    Dim linea As String
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        fichero = New StreamWriter("d:\NOTAS.txt")

        fichero.WriteLine("La primera linea")
        fichero.WriteLine("de un microcuento")
        fichero.WriteLine("que no acaba aquí")
        fichero.Write("porque estamos probando")
        fichero.WriteLine("WriteLine y Write")
        fichero.WriteLine("FIN")

        fichero.Close()
        MessageBox.Show("Fichero creado")


    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        lector = New StreamReader("d:\NOTAS.txt")


        linea = lector.ReadLine()
        MessageBox.Show("Contenido de la primera linea: " & linea)

        linea = lector.ReadLine()
        MessageBox.Show("Contenido de la 2ª linea: " & linea)

        Dim texto As String
        texto = lector.ReadToEnd()
        MessageBox.Show("Resto del archivo: " & texto)
        lector.Close()

    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        fichero = New StreamWriter("d:\NOTAS.txt", True) 'añade texto al final del archivo creado
        fichero.WriteLine("Esto es otro nueva linea")

        'linea = lector.ReadLine()
        'MessageBox.Show("Última línea: " & linea)

        fichero.Close()

    End Sub
End Class
