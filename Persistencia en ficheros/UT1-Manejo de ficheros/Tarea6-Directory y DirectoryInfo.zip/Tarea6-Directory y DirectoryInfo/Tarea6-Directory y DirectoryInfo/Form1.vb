﻿Imports System
Imports System.IO

Public Class Form1
    Private Sub btn1_Click(sender As System.Object, e As System.EventArgs) Handles btn1.Click
        Dim ruta As String = "c:\" & TextBox1.Text

        Try
            If Not Directory.Exists(ruta) Then
                Directory.CreateDirectory(ruta)
                MessageBox.Show("Directorio creado")
            ElseIf Directory.Exists(ruta) Then
                MessageBox.Show("El directorio existe")
            End If
        Catch ex As Exception
            MessageBox.Show("El proceso falló: {0}", ex.ToString())

        End Try
    End Sub
    Private Sub btn2_Click(sender As System.Object, e As System.EventArgs) Handles btn2.Click
        Dim di As DirectoryInfo = New DirectoryInfo("c:\" & TextBox1.Text)
        Try
            If di.Exists Then
                MessageBox.Show("El directorio existe")
            Else
                di.Create()
                MessageBox.Show("Directorio creado")
            End If
        Catch ex As Exception
            MessageBox.Show("El proceso falló: {0}", ex.ToString())
        End Try
    End Sub
    Private Sub btn3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn3.Click
        Dim ruta As String = "c:\" & TextBox1.Text
      
        If Directory.Exists(ruta) Then
            Dim cont As String
            cont = CStr(Directory.GetFiles(ruta, "*.*", SearchOption.AllDirectories).Count())
            MessageBox.Show("El directorio '" + ruta + "' tiene: " + cont + " archivos")
        Else
            MessageBox.Show("El directorio '" + ruta + "' NO existe")
        End If

    End Sub

    Private Sub btn4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn4.Click
        Dim ruta As String = "c:\" & TextBox1.Text
        Dim di As New DirectoryInfo(ruta)
        If di.Exists Then
            Dim num As String
            num = CStr(di.GetFiles("*.*", SearchOption.AllDirectories).Count())
            MessageBox.Show("El directorio '" + ruta + "' tiene: " + num + " archivos")
        Else
            MessageBox.Show("El directorio '" + ruta + "' NO existe")
        End If
    End Sub

    Private Sub btn5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn5.Click

        Dim ruta As String = "d:\" & TextBox1.Text

        'If Not Directory.Exists(ruta) Then
        '    MessageBox.Show("La carpeta no existe")
        '    Exit Sub
        'End If
        Dim extension As String = InputBox("Introduzca extensión")
        Dim searchOption As SearchOption
        Dim archi As String
        Try
            archi = Directory.GetFiles(ruta, "*." & extension, searchOption).Count()
            MessageBox.Show(archi)
        Catch ex As DirectoryNotFoundException
            MessageBox.Show("No se encontró el directorio")
        End Try


    End Sub

    Private Sub btn6_Click(sender As System.Object, e As System.EventArgs) Handles btn6.Click
        Dim ruta As String = "d:\" & TextBox1.Text
        Dim di As New DirectoryInfo(ruta)

        'If Not di.Exists Then
        '    MessageBox.Show("No existe la carpeta")
        '    Exit Sub
        'End If
        Dim extension As String = InputBox("Introduzca extensión")
        Dim archi As Integer
        Try
            
            archi = di.GetFiles("*." & extension, SearchOption.AllDirectories).Count
            MessageBox.Show(archi)
        Catch ex As DirectoryNotFoundException
            MessageBox.Show("No se encontró el directorio")
        End Try

    End Sub

    Private Sub btnSalir_Click(sender As System.Object, e As System.EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub
End Class
