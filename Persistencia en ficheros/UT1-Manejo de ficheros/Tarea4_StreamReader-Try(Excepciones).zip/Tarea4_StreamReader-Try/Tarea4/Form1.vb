﻿Imports System.IO

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            Dim fichero As String
            fichero = "c:\Visual_17-18\" & TextBox1.Text & ".txt"
            Dim sr As StreamReader
            sr = New StreamReader(fichero)
            While (sr.Peek() > -1)
                MessageBox.Show(sr.ReadLine())
            End While
            sr.Close()
        Catch ex As Exception
            MessageBox.Show("se detecta un error genérico " & ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            Dim fichero As String
            fichero = "c:\Visual_17-18\" & TextBox1.Text & ".txt"
            Dim sr As StreamReader
            sr = New StreamReader(fichero)
            While (sr.Peek() > -1)
                MessageBox.Show(sr.ReadLine())
            End While
            sr.Close()
        Catch ex As FileNotFoundException
            MessageBox.Show("se detecta un error: " & ex.Message)
        Catch ex As DirectoryNotFoundException
            MessageBox.Show("se detecta un error: " & ex.Message)
        Catch ex As NotSupportedException
            MessageBox.Show("se detecta un error: " & ex.Message)
        Catch ex As ArgumentException
            MessageBox.Show("se detecta un error: " & ex.Message)

        End Try
    End Sub
End Class
