﻿Imports System
Imports System.IO
Public Class Form1

    Private Sub btnPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.Click

        ' Directorio actual.
        Dim ruta As String
        ruta = Directory.GetCurrentDirectory()
        MessageBox.Show(ruta)

        'Directorio temporal
        Dim temp = "c:\temp"
        If Directory.Exists(temp) Then
            MessageBox.Show("El directorio " + temp + " existe")
        Else
            MessageBox.Show("El directorio " + temp + "no existe")
            Directory.CreateDirectory(temp)
        End If

        ' Cambiamos de directorio.
        Directory.SetCurrentDirectory(temp)
        MessageBox.Show("Esta en: " + temp)
        Directory.SetCurrentDirectory(ruta)
        MessageBox.Show("Ha cambiado a: " + ruta)




    End Sub

    Private Sub btn2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2.Click
        Dim array() As String = Directory.GetLogicalDrives
        For i = 0 To array.Length - 1
            MessageBox.Show(array(i))
        Next
    End Sub

    Private Sub btn3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn3.Click
        'rev
        Dim di As DirectoryInfo = New DirectoryInfo("d:\pruebas\subdir")
        For Each fi In di.GetFiles("*", SearchOption.AllDirectories)
            MessageBox.Show(fi.Name)
        Next

        Dim archivos = Directory.GetFiles("d:\pruebas\subdir", "*.docx")
        For Each arch In archivos
            If File.GetAttributes(arch) = 1 Then
                MessageBox.Show(arch)
            End If
        Next
    End Sub

    Private Sub btn4_Click(sender As System.Object, e As System.EventArgs) Handles btn4.Click
        Dim archivo As String
        archivo = Dir("c:\*.*", vbHidden)
        Do While archivo <> ""
            archivo = Dir()
            MessageBox.Show(archivo)
        Loop

    End Sub

    Private Sub btn5_Click(sender As System.Object, e As System.EventArgs) Handles btn5.Click
        'My.Computer.FileSystem.CreateDirectory("C:\AD\UT2\Pruebas")
        Dim ruta As String = "D:\AD\UT2\Pruebas"

        If Directory.Exists(ruta) Then
            MessageBox.Show("Existe")
        Else
            Dim directorio = Directory.CreateDirectory(ruta)
            MessageBox.Show("Directorio Creado")
        End If
    End Sub

    Private Sub btn6_Click(sender As System.Object, e As System.EventArgs) Handles btn6.Click
        

        Dim archivos As String() = Directory.GetFiles("d:\pruebas\subdir", "*.txt")
        For Each arch In archivos
            MessageBox.Show(arch)
        Next
    End Sub

    Private Sub btn7_Click(sender As System.Object, e As System.EventArgs) Handles btn7.Click


        Try
            Dim path As String = "c:\AD\UT2\Pruebas"
            If Directory.Exists(path) = False Then
                Directory.CreateDirectory(path)
            End If

            'última fecha de acceso del directorio
            Dim dt As DateTime = Directory.GetLastAccessTime(path)
            MessageBox.Show("La ultima fecha de acceso del directorio fue " + dt)

            'Actualizacion de la fecha
            Directory.SetLastAccessTime(path, DateTime.Now)
            dt = Directory.GetLastAccessTime(path)
            MessageBox.Show("La ultima fecha de acceso del este directorio " + dt)

        Catch ex As Exception
            MessageBox.Show("Error " + e.ToString())
        End Try

        
    End Sub

    Private Sub btn8_Click(sender As System.Object, e As System.EventArgs) Handles btn8.Click
        Dim ruta As String = "C:\"
        Dim directorios() As String = Directory.GetDirectories(ruta)
        For Each directorio In directorios
            MessageBox.Show(directorio)
        Next
    End Sub

    Private Sub btn9_Click(sender As System.Object, e As System.EventArgs) Handles btn9.Click
        Dim ruta() As String = Directory.GetFiles("c:\", "*.txt")
        'Dim archivo As String
        For Each archivo In ruta
            MessageBox.Show(archivo)
        Next
    End Sub

    Private Sub btn10_Click(sender As System.Object, e As System.EventArgs) Handles btn10.Click
        'rev
        Try
            Dim ruta As String = "C:\"
            Dim dir As New DirectoryInfo(ruta)
            Dim array As Array = dir.GetDirectories("*", SearchOption.AllDirectories)
            For i = 0 To array.Length - 1
                MessageBox.Show("DIRECTORIO: " & array(i).ToString)
                Dim dir2 As New DirectoryInfo(ruta & "\" & array(i).ToString)
                Dim array2() As FileInfo = dir2.GetFiles
                For j = 0 To array2.Length - 1
                    Dim file As FileInfo = (array2(j))
                    MessageBox.Show("FICHERO: " & file.Name & " - " & file.CreationTime)
                Next
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub bnt11_Click(sender As System.Object, e As System.EventArgs) Handles bnt11.Click
        Dim nombreBien As String = "D:\pruebas\subdir"
        Dim nombreMal As String = "D:\pruebas\"
        Dim resul As String
        resul = Path.ChangeExtension(nombreBien, "old")
        MessageBox.Show(nombreBien, resul)
        resul = Path.ChangeExtension(nombreBien, "")
        MessageBox.Show(nombreBien, resul)
        resul = Path.ChangeExtension(nombreMal, ".old")
        MessageBox.Show(nombreMal, resul)
    End Sub

    Private Sub bnt12_Click(sender As System.Object, e As System.EventArgs) Handles bnt12.Click
        'METODO GETFULLPATH
        'Dim fileName As String = "Socio.txt"
        'Dim ruta1 As String = "d:\pruebas"
        'Dim ruta2 As String = "\pruebas"
        'Dim rutaComp As String

        'rutaComp = Path.GetFullPath(ruta1)
        'MessageBox.Show(fileName, rutaComp)

        'rutaComp = Path.GetFullPath(fileName)
        'MessageBox.Show(fileName, rutaComp)

        'rutaComp = Path.GetFullPath(ruta2)
        'MessageBox.Show(ruta2, rutaComp)


        'METODO COMBINE
        'Dim ruta1 As String = "c:\temp"
        'Dim ruta2 As String = "subdir\file.txt"
        'Dim ruta3 As String = Path.Combine(ruta1, ruta2)

        'MessageBox.Show("Ruta 1: " & ruta1)
        'MessageBox.Show("Ruta 2: " & ruta2)
        'MessageBox.Show("El resultado de la combinación es: " & ruta3)

        'Con arrays
        Dim ruta() As String = {"d:\pruebas", "2017", "media", "imagenes"}
        Dim rutaComp As String = Path.Combine(ruta)
        MessageBox.Show(rutaComp)

    End Sub
End Class
