﻿Imports System.IO

Public Class lb2
    Private fichero As StreamWriter
    Private reader As StreamReader
    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim lista = DriveInfo.GetDrives()
        Dim d As DriveInfo
        For Each d In lista
            cb.Items.Add(d.Name)
        Next
    End Sub

    Private Sub cb_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cb.SelectedIndexChanged
        lb1.Items.Clear()
        dirc = cb.SelectedItem
        Try
            a = Directory.GetDirectories(dirc)
            For Each b As String In a
                lb1.Items.Add(b)
            Next
        Catch ex As Exception
            MessageBox.Show("No se puede acceder a los directorios")
        End Try

    End Sub

    Private Sub lb1_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles lb1.SelectedIndexChanged
        lbox2.Items.Clear()
        dirc = lb1.SelectedItem + "\*.txt"
        Archivo = Dir(dirc, vbNormal)
        Dim a As String = ""
        Do While Archivo <> ""
            lbox2.Items.Add(Archivo)
            'Salto de linea
            Archivo = Dir()
        Loop
    End Sub

    Private Sub lbox2_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles lbox2.SelectedIndexChanged
        Dim dir As String = lb1.SelectedItem + "\" + lbox2.SelectedItem
        reader = New StreamReader(dir)
        txt.Text = reader.ReadToEnd()
        reader.Close()

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim dir As String = lb1.SelectedItem + "\" + lbox2.SelectedItem
        fichero = New StreamWriter(dir, False)
        fichero.WriteLine(txt.Text)
        fichero.Close()
        MessageBox.Show("Texto guardado.")
    End Sub
End Class
