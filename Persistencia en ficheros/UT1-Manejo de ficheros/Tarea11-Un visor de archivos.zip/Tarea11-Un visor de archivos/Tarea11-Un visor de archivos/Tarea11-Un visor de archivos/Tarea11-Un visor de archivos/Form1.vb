﻿Imports System
Imports System.IO

Public Class Form1

    Private Sub CBUnidad_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles CBUnidad.SelectedIndexChanged

        lbCarpetas.Items.Clear()
        lbArchivos.Items.Clear()
        Dim ruta As String
        ruta = CBUnidad.SelectedItem
        Try
            Dim directorios() As String = Directory.GetDirectories(ruta)
            Dim directorio As String
            For Each directorio In directorios
                lbCarpetas.Items.Add(directorio)
            Next
        Catch ex As IOException
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub lbCarpetas_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles lbCarpetas.SelectedIndexChanged
        lbArchivos.Items.Clear()
        Dim ruta As String
        ruta = lbCarpetas.SelectedItem
        Try
            Dim ficheros() As String = Directory.GetFiles(ruta, "*.txt", SearchOption.AllDirectories)
            Dim fichero As String
            For Each fichero In ficheros
                lbArchivos.Items.Add(Path.GetFileName(fichero))
            Next
        Catch ex As UnauthorizedAccessException
            MessageBox.Show(ex.Message)
        End Try
        
    End Sub

    Private Sub lbArchivos_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles lbArchivos.SelectedIndexChanged
        txtContenido.Text = ""
        Dim ruta, rutaCompleta, fichero As String
        ruta = lbCarpetas.SelectedItem
        rutaCompleta = ""

        Dim ficheros() As String = Directory.GetFiles(ruta, "*.txt", SearchOption.AllDirectories)
        For Each fichero In ficheros
            rutaCompleta = ficheros(lbArchivos.SelectedIndex)
        Next

        Dim lector As StreamReader = New StreamReader(rutaCompleta)
        Dim texto As String
        texto = lector.ReadToEnd()
        txtContenido.Text = texto
        lector.Close()
    End Sub

    Private Sub btnGuardar_Click(sender As System.Object, e As System.EventArgs) Handles btnGuardar.Click
        Dim ruta, rutaCompleta, fichero As String
        ruta = lbCarpetas.SelectedItem
        rutaCompleta = ""

        Dim ficheros() As String = Directory.GetFiles(ruta, "*.txt", SearchOption.AllDirectories)
        For Each fichero In ficheros
            rutaCompleta = ficheros(lbArchivos.SelectedIndex)
        Next

        Dim escritor As StreamWriter
        escritor = New StreamWriter(rutaCompleta)

        Dim texto As String
        texto = txtContenido.Text
        escritor.WriteLine(texto)
        escritor.Close()
        MessageBox.Show("Guardado")
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim unidades() As String = Directory.GetLogicalDrives 'nos da las unidades, c:\,d:\,...
        Dim unidad As String
        For Each unidad In unidades
            CBUnidad.Items.Add(unidad)
        Next
    End Sub
End Class
