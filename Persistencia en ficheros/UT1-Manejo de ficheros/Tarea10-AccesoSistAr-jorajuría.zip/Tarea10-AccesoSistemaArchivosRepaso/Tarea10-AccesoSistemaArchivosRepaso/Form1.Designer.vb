﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmbAcciones = New System.Windows.Forms.ComboBox()
        Me.btnEjecutar = New System.Windows.Forms.Button()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'cmbAcciones
        '
        Me.cmbAcciones.FormattingEnabled = True
        Me.cmbAcciones.Location = New System.Drawing.Point(24, 33)
        Me.cmbAcciones.Name = "cmbAcciones"
        Me.cmbAcciones.Size = New System.Drawing.Size(257, 21)
        Me.cmbAcciones.TabIndex = 0
        '
        'btnEjecutar
        '
        Me.btnEjecutar.Location = New System.Drawing.Point(287, 33)
        Me.btnEjecutar.Name = "btnEjecutar"
        Me.btnEjecutar.Size = New System.Drawing.Size(108, 21)
        Me.btnEjecutar.TabIndex = 1
        Me.btnEjecutar.Text = "&Ejecutar"
        Me.btnEjecutar.UseVisualStyleBackColor = True
        '
        'btnSalir
        '
        Me.btnSalir.Location = New System.Drawing.Point(24, 60)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(371, 21)
        Me.btnSalir.TabIndex = 2
        Me.btnSalir.Text = "&Salir"
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AcceptButton = Me.btnEjecutar
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(422, 110)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.btnEjecutar)
        Me.Controls.Add(Me.cmbAcciones)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(438, 149)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(438, 149)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Repaso del sistema de archivos"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmbAcciones As System.Windows.Forms.ComboBox
    Friend WithEvents btnEjecutar As System.Windows.Forms.Button
    Friend WithEvents btnSalir As System.Windows.Forms.Button

End Class
