﻿Imports System.IO
Public Class Form1

    Private opc(,) As String = {{"Directorio de trabajo actual", "directorioDeTrabajo"},
                               {"Ruta raíz de todas las unidades", "mostrarRutaRaiz"},
                               {"Archivos de lectura .docx", "mostrarArchivosDeLectura"},
                               {"Mostrar archivos ocultos de C:\", "mostrarArchivosOcultosC"},
                               {"Crear directorio", "crearDirectorio"},
                               {"Mostrar los archivos .txt", "mostrarArchivosTxtDir"},
                               {"Establecer hoy como última fecha de acceso", "establecerFechaUltAcceso"},
                               {"Listar los directorios en F:\", "listarDirectoriosF"},
                               {"Listar archivos .txt de F:\", "listarArchivosTxtF"},
                               {"Cambiar la extensión de un archivo, en su ruta", "cambiarExtensionPath"}}

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim op(opc.GetLength(0) - 1) As String
        For i = 0 To op.Length - 1
            op(i) = opc(i, 0)
        Next
        cmbAcciones.Items.AddRange(op)
        cmbAcciones.SelectedIndex = 0
    End Sub

    Private Sub ejecutar(sender As System.Object, e As System.EventArgs) Handles btnEjecutar.Click
        Dim opE As Integer
        opE = cmbAcciones.SelectedIndex
        Try
            If opE >= 0 And opc(opE, 1) <> "" Then
                Try
                    CallByName(Me, opc(opE, 1), CallType.Method)
                Catch
                    MessageBox.Show("Ha ocurrido un error al llamar al método", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If
        Catch
        End Try
    End Sub

    Sub directorioDeTrabajo()
        MessageBox.Show("Directorio actual de trabajo " & vbCrLf & Directory.GetCurrentDirectory)
        If Not Directory.Exists("C:\temp") Then
            Directory.CreateDirectory("C:\temp")
        End If
        Dim dirOriginal As String = Directory.GetCurrentDirectory
        Directory.SetCurrentDirectory("C:\temp")
        MessageBox.Show("Directorio actual de trabajo " & vbCrLf & Directory.GetCurrentDirectory)
        Directory.SetCurrentDirectory(dirOriginal)
        MessageBox.Show("Directorio actual de trabajo " & vbCrLf & Directory.GetCurrentDirectory)
    End Sub

    Sub mostrarRutaRaiz()
        For Each Dir As DriveInfo In DriveInfo.GetDrives()
            MessageBox.Show(Directory.GetDirectoryRoot(Dir.Name))
        Next
    End Sub

    Sub mostrarArchivosDeLectura()
        Dim ruta As String = InputBox("Introduzca ruta: ")
        Dim dir As DirectoryInfo = New DirectoryInfo(ruta)
        Dim archivos As String = ""
        For Each f In dir.EnumerateFiles
            If f.IsReadOnly And f.Extension = ".docx" Then
                archivos += f.Name + vbCrLf
            End If
        Next
        If archivos <> "" Then
            MessageBox.Show("En la ruta: " & ruta & " se han encontrado los siguientes archivos .docx:" & vbCrLf & vbCrLf & archivos)
        Else
            MessageBox.Show("No se ha encontrado ningún .docx de sólo lectura", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        End If
    End Sub

    Sub mostrarArchivosOcultosC()
        Dim dir As DirectoryInfo = New DirectoryInfo("C:\")
        Dim archivos As String = ""
        For Each f In dir.EnumerateFiles
            If f.Attributes.ToString.Contains("Hidden") Then
                archivos += f.Name + vbCrLf
            End If
        Next
        If archivos <> "" Then
            MessageBox.Show("En C:\ se han encontrado los siguientes archivos ocultos:" & vbCrLf & vbCrLf & archivos)
        Else
            MessageBox.Show("No se ha encontrado ningún archivo oculto", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        End If
    End Sub

    Sub crearDirectorio()
        Dim dir As String = InputBox("Introduzca directorio", "Introducir", "C:\AD\UT2\Pruebas")
        If Not Directory.Exists(dir) Then
            Directory.CreateDirectory(dir)
            MessageBox.Show("Directorio creado", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        Else
            MessageBox.Show("El directorio ya existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Sub mostrarArchivosTxtDir()
        Dim ruta As String = InputBox("Introduzca directorio", "Introducir", "C:\AD\UT2\Pruebas")
        If Directory.Exists(ruta) Then
            Dim dir As DirectoryInfo = New DirectoryInfo(ruta)
            Dim archivos As String = ""
            For Each f In dir.EnumerateFiles
                If f.Extension = ".txt" Then
                    archivos += f.Name + vbCrLf
                End If
            Next
            If archivos <> "" Then
                MessageBox.Show("En la ruta: " & ruta & " se han encontrado los siguientes archivos .txt:" & vbCrLf & vbCrLf & archivos)
            Else
                MessageBox.Show("No se ha encontrado ningún .txt", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            End If
        Else
            MessageBox.Show("El directorio ya existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Sub establecerFechaUltAcceso()
        Dim ruta As String = "C:\AD\UT2\Pruebas"
        If Directory.Exists(ruta) Then
            Dim dir As DirectoryInfo = New DirectoryInfo(ruta)
            For Each f In dir.EnumerateFiles
                f.LastAccessTime = DateTime.Now

            Next
            MessageBox.Show("Fecha establecida", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        Else
            MessageBox.Show("El directorio no existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Sub listarDirectoriosF()
        Dim dir As DirectoryInfo = New DirectoryInfo("F:\")
        If dir.Exists Then
            Dim resultado As String = ""
            For Each sd In dir.EnumerateDirectories()
                resultado += sd.Name & vbCrLf
            Next
            If resultado <> "" Then
                MessageBox.Show("'F:\' contiene los siguientes subdirectorios:" & vbCrLf & vbCrLf & resultado, "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("No se ha encontrado ningún subdirectorio", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            End If
        Else
            MessageBox.Show("El directorio 'F:\' no existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Sub listarArchivosTxtF()
        Dim ruta As String = "C:\"
        If Directory.Exists(ruta) Then
            Dim dir As DirectoryInfo = New DirectoryInfo(ruta)
            MessageBox.Show("¿Revisar subdirectorios?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            Dim archivos As String = ""
            For Each f In dir.EnumerateFiles
                If f.Extension = ".txt" Then
                    archivos += f.Name + vbCrLf
                End If
            Next
            If archivos <> "" Then
                MessageBox.Show("En la ruta: " & ruta & " se han encontrado los siguientes archivos .txt:" & vbCrLf & vbCrLf & archivos, "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("No se ha encontrado ningún .txt", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            End If
        Else
            MessageBox.Show("El directorio no existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Sub cambiarExtensionPath()
        Dim ruta As String = InputBox("Introduzca ruta:", "Cambiar extensión")
        Dim nueva As String = Path.ChangeExtension(ruta, InputBox("Introduzca nueva extensión:", "Cambiar extensión"))
        MessageBox.Show("La nueva ruta es: " & nueva, "Cambiar extensión", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub btnSalir_Click(sender As System.Object, e As System.EventArgs) Handles btnSalir.Click
        Me.Dispose()
    End Sub
End Class
