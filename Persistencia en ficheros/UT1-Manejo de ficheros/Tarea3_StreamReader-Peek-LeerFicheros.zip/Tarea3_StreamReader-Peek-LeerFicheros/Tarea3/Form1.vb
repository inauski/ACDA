﻿Imports System.IO

Public Class Form1

    Private Sub btLeer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btLeer.Click
        'PEEK
        Try
            Dim fichero As String
            fichero = "d:\" & TextBox1.Text & ".txt" ' Si ponemos txt entre comillas al final, luego a la hora de escribirlo en el textBox no lo tenemos que escribir
            If (File.Exists(fichero)) Then
                Dim sr As StreamReader
                sr = New StreamReader(fichero)
                While (sr.Peek() > -1)
                    MessageBox.Show(sr.ReadLine())
                End While
                sr.Close()
            Else
                MessageBox.Show("Fichero inexistente")
            End If
        Catch ex As Exception
            MessageBox.Show("ERROR")
        End Try

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Leer normal
        Try
            Dim linea As String = "A"
            Dim fichero As String
            fichero = "d:\" & TextBox1.Text & ".txt" 'Directamente se busca en el archivo Socios.txt ubicado en d, es mejor la opcion de arriba pq aqui pongamos lo q pongamos en el textBox solo va a buscar ese archivo

            If (File.Exists(fichero)) Then
                Dim sr As StreamReader
                sr = New StreamReader(fichero)
                While linea <> ""
                    linea = sr.ReadLine()
                    If linea = "" Then
                        Exit Sub
                    Else
                        MessageBox.Show(linea)
                    End If
                End While
            Else
                MessageBox.Show("Fichero inexistente")
            End If
        Catch ex As Exception
            MessageBox.Show("ERROR")
        End Try
    End Sub
End Class
