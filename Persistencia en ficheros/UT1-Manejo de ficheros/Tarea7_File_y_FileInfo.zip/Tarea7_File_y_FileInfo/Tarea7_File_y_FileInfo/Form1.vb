﻿Imports System
Imports System.IO
Public Class Form1

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        Dim ruta1 As String = TextBox1.Text
        If File.Exists(ruta1) Then

            TextBox1.Text = ruta1
            MessageBox.Show("Ruta del fichero: " + Path.GetDirectoryName(ruta1))
            MessageBox.Show("La extension es: " + Path.GetExtension(ruta1))
            MessageBox.Show(CStr("Ultima fecha de edicion: " & File.GetLastWriteTime(ruta1)))
            MessageBox.Show("Longitud en bytes del archivo: " + (CStr(File.ReadAllBytes(ruta1).Length)))

        Else
            MessageBox.Show("El fichero no existe")
        End If
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Dim ruta1 As String = TextBox1.Text
        Dim fi As FileInfo = New FileInfo(ruta1)

        If fi.Exists Then
            MessageBox.Show("Ruta del fichero: " + fi.DirectoryName) 'tb posible FullName
            MessageBox.Show("La extension es: " + fi.Extension)
            MessageBox.Show(CStr("Ultima fecha de edicion: " & fi.LastWriteTime))
            MessageBox.Show(CStr("Longitud en bytes del archivo: " & fi.Length))
        Else
            MessageBox.Show("El fichero no existe")
        End If
    End Sub
End Class
