﻿Imports System.IO
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        For Each ch As Char In Path.GetInvalidFileNameChars()
            MessageBox.Show(ch)
        Next ch
    End Sub
End Class
